// ===== [TIMELINE-DATA] =====
// EDIT: ini daftar kenangannya. "foto: null" artinya slot buat foto BARU
// yang belum ditaruh — ganti null dengan path foto (taruh filenya di
// folder img/ dulu), dan ganti "keterangan" sesuai cerita aslinya.
const daftarKenangan = [
  { foto: "img/Picture4.jpg", keterangan: "Satu dari banyak momen favorit." },
  { foto: null, keterangan: "Ini juga bagian dari cerita kita." },
  { foto: "img/Picture6.jpg", keterangan: "Ketawa gara-gara apa ya waktu itu?" },
  { foto: null, keterangan: "Kenangan kecil yang nggak kelupaan." },
  { foto: "img/Picture8.jpg", keterangan: "Selalu suka lihat ini lagi." },
  { foto: null, keterangan: "Sampai ketemu momen berikutnya." },
];
// ===== END [TIMELINE-DATA] =====

// ===== [TIMELINE-RENDER] =====
const kontainer = document.getElementById("daftar-kenangan");

daftarKenangan.forEach((item, i) => {
  const kartu = document.createElement("div");
  kartu.className = "tl-kartu " + (i % 2 === 0 ? "tl-kartu--kiri" : "tl-kartu--kanan");
  // sedikit miring acak, biar berasa ditaruh tangan bukan mesin
  const miring = (Math.random() * 6 - 3).toFixed(1);
  kartu.style.setProperty("--miring", miring + "deg");

  if (item.foto) {
    const img = document.createElement("img");
    img.src = item.foto;
    img.alt = "Foto kenangan";
    kartu.appendChild(img);
  } else {
    const placeholder = document.createElement("div");
    placeholder.className = "tl-kartu__placeholder";
    placeholder.textContent = "+ taruh foto baru di sini (img/ folder)";
    kartu.appendChild(placeholder);
  }

  const teks = document.createElement("p");
  teks.className = "tl-kartu__keterangan";
  teks.textContent = item.keterangan;
  kartu.appendChild(teks);

  kontainer.appendChild(kartu);
});
// ===== END [TIMELINE-RENDER] =====

// ===== [TIMELINE-OBSERVER] =====
// Kartu baru "muncul" (fade + geser naik) begitu masuk layar,
// bukan langsung semua kelihatan dari awal.
const pengamat = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("tampak");
      }
    });
  },
  { threshold: 0.3 }
);

document.querySelectorAll(".tl-kartu").forEach((kartu) => pengamat.observe(kartu));
// ===== END [TIMELINE-OBSERVER] =====
