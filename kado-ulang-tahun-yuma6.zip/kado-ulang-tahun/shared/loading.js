// ===== LOADING SCREEN (ASCII) =====
// Hati ASCII terisi dari bawah sesuai persen, dan loading bar-nya berupa teks.
// Progress-nya angka simulasi (biar keliatan gerak halus), TAPI layarnya
// baru beneran hilang setelah dua syarat terpenuhi:
//   1) window "load" beneran selesai (semua iframe/font/gambar termuat)
//   2) simulasi progress udah nyampe 100%
// Analoginya kayak nunggu microwave: angka mundurnya bisa aja lebih
// cepat dari makanan yang beneran matang, kita tetap nunggu dua-duanya.

(function () {
  const layar = document.getElementById("layarLoading");
  const hatiEl = document.getElementById("loadingHati");
  const barEl = document.getElementById("loadingBar");

  const LEBAR_BAR = 20; // jumlah kotak di loading bar
  const hati = petakHati(36, 0.55);
  const KARAKTER_ISI = "@#%&*";

  let progresSimulasi = 0;
  let halamanSudahLoad = false;

  // Baris hati yang terisi dihitung dari bawah: 50% = separuh bawah hati
  function gambarHati(persen) {
    const baris = hati.length;
    const terisi = Math.floor((persen / 100) * baris);
    let html = "";
    for (let r = 0; r < baris; r++) {
      const sudahTerisi = baris - 1 - r < terisi;
      for (let c = 0; c < hati[r].length; c++) {
        if (!hati[r][c]) html += " ";
        else if (sudahTerisi) html += "<b>" + KARAKTER_ISI[(r * 7 + c * 3) % KARAKTER_ISI.length] + "</b>";
        else html += "<i>.</i>";
      }
      html += "\n";
    }
    hatiEl.innerHTML = html;
  }

  function setProgres(persen) {
    progresSimulasi = Math.min(persen, 100);
    const isi = Math.round((LEBAR_BAR * progresSimulasi) / 100);
    barEl.textContent =
      "[" + "#".repeat(isi) + "-".repeat(LEBAR_BAR - isi) + "] " + Math.round(progresSimulasi) + "%";
    gambarHati(progresSimulasi);
  }
  setProgres(0);

  // naik pelan-pelan, tapi sengaja ditahan di 90% sampai window "load"
  // beneran kelar, biar progress bar nggak bohong nyampe 100% duluan
  const interval = setInterval(() => {
    const langkah = Math.random() * 8 + 4;
    const batas = halamanSudahLoad ? 100 : 90;
    setProgres(Math.min(progresSimulasi + langkah, batas));
    if (progresSimulasi >= 100) {
      clearInterval(interval);
      selesaikanLoading();
    }
  }, 200);

  window.addEventListener("load", () => {
    halamanSudahLoad = true;
  });

  function selesaikanLoading() {
    setTimeout(() => {
      layar.classList.add("selesai");
      setTimeout(() => layar.remove(), 700);
    }, 250);
  }
})();
// ===== END LOADING SCREEN =====
